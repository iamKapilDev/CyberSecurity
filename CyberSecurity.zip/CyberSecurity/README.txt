Steps for Execution : 


1 . open the command prompt for the jar location.

2. execute the below command



source file = json_file.json (input)

target file = xml_file.json  (output) Not monitory to create a File


Example
java -jar CyberSecurity.jar json_file.json xml_file.json
        